package com.learning.java8.Java8NewFeatureDurgaSoft.RazorPayInterview;

import java.util.List;

public interface User {

    List<String> getEmail();

}
